﻿#include "$project_name$/src/pch.h"
#include "$project_name$/include/scene_$scene_name$/asset_group.h"

$project_name$::$SceneName$AssetGroup::$SceneName$AssetGroup()
{
    
}