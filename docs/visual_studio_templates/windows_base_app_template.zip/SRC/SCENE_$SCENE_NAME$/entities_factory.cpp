﻿#include "$project_name$/src/pch.h"
#include "$project_name$/include/scene_$scene_name$/entities_factory.h"

void $project_name$::$SceneName$EntitiesFactory::Create
(
    wb::IAssetContainer &assetCont, 
    wb::IEntityContainer &entityCont, 
    wb::IComponentContainer &componentCont, 
    wb::IEntityIDView &entityIDView
) const
{
    
}