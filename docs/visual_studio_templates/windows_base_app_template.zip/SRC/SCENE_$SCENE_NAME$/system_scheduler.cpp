﻿#include "$project_name$/src/pch.h"
#include "$project_name$/include/scene_$scene_name$/system_scheduler.h"

void $project_name$::$SceneName$SystemScheduler::Execute(wb::ISystemContainer &systemCont, wb::SystemArgument &args)
{
    
}