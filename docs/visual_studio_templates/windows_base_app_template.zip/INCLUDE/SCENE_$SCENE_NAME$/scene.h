﻿#pragma once
#include "windows_base/windows_base.h"

namespace $project_name$
{
    const size_t &$SceneName$SceneFacadeID();

} // namespace $project_name$