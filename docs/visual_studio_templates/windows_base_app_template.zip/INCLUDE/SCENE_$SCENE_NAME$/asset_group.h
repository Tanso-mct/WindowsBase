﻿#pragma once
#include "windows_base/windows_base.h"

namespace $project_name$
{
    class $SceneName$AssetGroup : public wb::AssetGroup
    {
    public:
        $SceneName$AssetGroup();
        ~$SceneName$AssetGroup() override = default;
    };

} // namespace $project_name$