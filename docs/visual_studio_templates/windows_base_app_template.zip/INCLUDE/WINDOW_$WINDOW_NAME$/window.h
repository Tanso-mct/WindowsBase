﻿#pragma once
#include "windows_base/windows_base.h"

namespace $project_name$
{
    const size_t &$WindowName$WindowID();

} // namespace $project_name$