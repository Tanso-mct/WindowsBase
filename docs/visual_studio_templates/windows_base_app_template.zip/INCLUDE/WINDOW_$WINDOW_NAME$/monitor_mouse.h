﻿#pragma once
#include "windows_base/windows_base.h"

namespace $project_name$
{
    const size_t &$WindowName$MouseMonitorID();

} // namespace $project_name$